package GlobalValue;

import java.awt.Font;

public class GlobalValue {
	public static final int nFrameWidth = 1280;
	public static final int nFrameHeight = 720;

	public static final int nTitleHeight = 30;
	public static final Font Font_Number=new Font("�޸�����ü",Font.BOLD,12);
	public static final Font Font_String =new Font("�޸�����ü",Font.BOLD,15);
	public static final int MAX_BUTTON_COUNT = 16;
}
