package Main.Frame.Body.View;

import java.awt.*;
import javax.swing.*;

public class HistoryView extends JPanel{
	
	public HistoryView() {
		// TODO Auto-generated constructor stub
		this.setLayout(null);
		this.setBackground(Color.CYAN);
		
	}
}
