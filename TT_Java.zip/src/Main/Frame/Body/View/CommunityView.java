package Main.Frame.Body.View;

import java.awt.*;
import javax.swing.*;

public class CommunityView extends JPanel{
	
	public CommunityView() {
		// TODO Auto-generated constructor stub
		this.setLayout(null);
		this.setBackground(Color.blue);
	}

}
