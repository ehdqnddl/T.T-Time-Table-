package Main.Frame.Body.View;

import java.awt.*;
import javax.swing.*;

public class CurriculumView extends JPanel{
	
	public CurriculumView() {
		// TODO Auto-generated constructor stub
		this.setLayout(null);
		this.setBackground(Color.YELLOW);
	}

}
