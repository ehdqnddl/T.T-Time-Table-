package Main.Frame.Body.View;

import java.awt.*;
import javax.swing.*;

public class CampusView extends JPanel{
	
	public CampusView() {
		// TODO Auto-generated constructor stub
		this.setLayout(null);
		this.setBackground(Color.RED);
		
	}

}
